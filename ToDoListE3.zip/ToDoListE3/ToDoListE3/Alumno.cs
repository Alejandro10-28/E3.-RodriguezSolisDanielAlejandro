﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ToDoListE3
{
   public class Alumno:Atributos
    {
        //Se encapsulan los atributos que tendra la clase alumnos
        public string NombreA { get; set; }
        public double NoControlA { get; set; }
    }
}
