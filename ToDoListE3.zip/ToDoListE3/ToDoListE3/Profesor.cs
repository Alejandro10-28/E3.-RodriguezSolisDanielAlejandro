﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ToDoListE3
{
    public class Profesor:Atributos
    {
        //Se encapsulan los atributos que tendra la clase profesor
        public string Nombrep { get; set; }
        public int NoControl { get; set; }
    }
}
